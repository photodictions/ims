<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmProductPurchase extends Model
{
    //
}
