<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmNewsPage extends Model
{
    //
}
