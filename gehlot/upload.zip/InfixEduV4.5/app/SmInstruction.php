<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmInstruction extends Model
{
    //
}
