<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmSupplier extends Model
{
    //
}
