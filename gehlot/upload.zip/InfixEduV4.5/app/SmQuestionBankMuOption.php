<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmQuestionBankMuOption extends Model
{
    //
}
