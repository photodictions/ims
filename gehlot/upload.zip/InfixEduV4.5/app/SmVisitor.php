<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmVisitor extends Model
{
    //
}
