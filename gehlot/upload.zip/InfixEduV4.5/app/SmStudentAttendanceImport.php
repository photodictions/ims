<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmStudentAttendanceImport extends Model
{
    //
}
