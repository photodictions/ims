<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmFeesDiscount extends Model
{
    //
}
