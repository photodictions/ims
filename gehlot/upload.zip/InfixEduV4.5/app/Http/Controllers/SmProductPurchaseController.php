<?php

namespace App\Http\Controllers;

use App\SmProductPurchase;
use Illuminate\Http\Request;

class SmProductPurchaseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SmProductPurchase  $smProductPurchase
     * @return \Illuminate\Http\Response
     */
    public function show(SmProductPurchase $smProductPurchase)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SmProductPurchase  $smProductPurchase
     * @return \Illuminate\Http\Response
     */
    public function edit(SmProductPurchase $smProductPurchase)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SmProductPurchase  $smProductPurchase
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SmProductPurchase $smProductPurchase)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SmProductPurchase  $smProductPurchase
     * @return \Illuminate\Http\Response
     */
    public function destroy(SmProductPurchase $smProductPurchase)
    {
        //
    }
}
