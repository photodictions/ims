<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmMarksSendSms extends Model
{
    //
}
