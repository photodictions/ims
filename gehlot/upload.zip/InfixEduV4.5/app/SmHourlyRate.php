<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmHourlyRate extends Model
{
    //
}
