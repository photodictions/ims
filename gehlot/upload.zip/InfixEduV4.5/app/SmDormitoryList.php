<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmDormitoryList extends Model
{
    //
}
