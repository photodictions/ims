<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmAboutPage extends Model
{
    //
}
