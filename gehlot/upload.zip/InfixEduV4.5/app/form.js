

var ss = allData;

return ss;