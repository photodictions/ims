<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmHrSalaryTemplate extends Model
{
    //
}
