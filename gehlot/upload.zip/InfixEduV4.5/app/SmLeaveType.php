<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmLeaveType extends Model
{
    //
}
