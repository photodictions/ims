<?php

namespace Modules\RolePermission\Entities;

use Illuminate\Database\Eloquent\Model;

class InfixModuleInfo extends Model
{
    protected $fillable = [];
}
