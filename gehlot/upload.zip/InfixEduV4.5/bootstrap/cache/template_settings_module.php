<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TemplateSettings\\Providers\\TemplateSettingsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TemplateSettings\\Providers\\TemplateSettingsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);